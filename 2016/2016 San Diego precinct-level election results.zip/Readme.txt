November 8th Presidential General Election - Official Election Results as of 12/8/2016.

Notes on the enclosed files:

20161108cv.txt:  This file contains information about each consolidated 
precinct,contest, candidate and statistics.  There are four types of 
records grouped under each contest and consolidated precinct.

1.  Registered Voters.
2.  Times Counted. 
3.  stats/candidate(label)or candidate name.
4.  Count Type.

Each of the above records has an associated field that identifies
the approprate value for that field.   

Registered voters = number of registered voters in the precinct
Times Counted = the number of ballots cast in the precinct.
Candidate name = number of votes the candidate received.
Count Type = Mail (Mail Ballot Voters), Polling and total votes

Each of these lines is repeated for each precinct and contest.

contest.txt:

This is a list of contest in the 20161108cv.txt with it's
contest_id.  You would use this table to isolate a contest in the 20161108cv.txt
file.

candidate.txt:

This is a list of candidates in the 20161108cv.txt with their
candidate_id.  You would use this table to isolate a candiate in the 20161108cv.txt
file.

98 - Consolidation to home precinct.txt:

This is a list that identifies the
home precinct(s) that makeup the consolidated precinct (polling place) or (Absentee).
Mail ballots were counted back to their consolidated Polling place precinct or 
The mail ballot precinct (999XXX) XXX= ballot type are vote by mail precincts.  

Precdist_AO_10-04-2016

This is a home precinct to district.  Use this to locate which districts are associated
to a consolidation.


Looking at Precinct breakdown reports in the PDF area.

Due to the large number of contests a second ballot card was created for each voter,  This card
started with Prop 64 and ended with any prop the ballot style included.  This caused some reports to show different
numbers than an election where the voter recieved only one card.  You may be looking at a report where the registration
to cards cast will show a number greater that 100% because one voter = 2 ballot cards.   There were also cases where
the voter only voted one of the ballots they were given,  that could have been either the A card or the B card,
this caused a different number of cards to be cast for say the presidential contest which was on card A and Prob 64 
which was on card B.



